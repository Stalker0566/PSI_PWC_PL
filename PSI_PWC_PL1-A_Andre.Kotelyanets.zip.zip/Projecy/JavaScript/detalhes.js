document.addEventListener("DOMContentLoaded", function () {
    const countryDetailsContainer = document.getElementById("country-details");
    const country = JSON.parse(localStorage.getItem("selectedCountry"));

    if (country) {
        const currencies = Object.values(country.currencies).map(currency => `${currency.name} (${currency.symbol})`).join(", ");
        const languages = Object.values(country.languages).join(", ");

        const countryHTML = `
            <table class="table table-bordered">
                <tbody>
                    <tr>
                        <th>Nome</th>
                        <td>${country.name.common}</td>
                    </tr>
                    <tr>
                        <th>Capital</th>
                        <td>${country.capital ? country.capital[0] : "N/A"}</td>
                    </tr>
                    <tr>
                        <th>Região</th>
                        <td>${country.region}</td>
                    </tr>
                    <tr>
                        <th>Sub-região</th>
                        <td>${country.subregion}</td>
                    </tr>
                    <tr>
                        <th>População</th>
                        <td>${country.population.toLocaleString()}</td>
                    </tr>
                    <tr>
                        <th>Área</th>
                        <td>${country.area.toLocaleString()} km²</td>
                    </tr>
                    <tr>
                        <th>Idioma(s)</th>
                        <td>${languages}</td>
                    </tr>
                    <tr>
                        <th>Moeda(s)</th>
                        <td>${currencies}</td>
                    </tr>
                    <tr>
                        <th>Bandeira</th>
                        <td><img src="${country.flags.png}" alt="Bandeira de ${country.name.common}" width="100"></td>
                    </tr>
                </tbody>
            </table>
        `;

        countryDetailsContainer.innerHTML = countryHTML;
    } else {
        countryDetailsContainer.innerHTML = "<p>Detalhes do país não encontrados.</p>";
    }
});