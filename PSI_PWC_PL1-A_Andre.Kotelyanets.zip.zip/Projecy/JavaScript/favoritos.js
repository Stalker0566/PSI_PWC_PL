// favoritos.js

document.addEventListener("DOMContentLoaded", function () {
    carregarFavoritos();
});

// Função para carregar os favoritos
function carregarFavoritos() {
    const container = document.getElementById('favorites-list');
    if (!container) {
        console.error("Elemento 'favorites-list' não encontrado.");
        return;
    }

    const favoritos = getFavoritos();
    container.innerHTML = ''; // Limpa o container antes de carregar os favoritos
    if (favoritos.length === 0) {
        container.innerHTML = '<p>Nenhum país foi adicionado aos favoritos ainda.</p>';
    } else {
        favoritos.forEach(country => {
            console.log("Exibindo país favorito:", country.name.common); // Log para depuração
            const countryCard = document.createElement('div');
            countryCard.classList.add('col-md-4', 'col-sm-6', 'mb-4');

            const countryHTML = `
                <div class="card h-100 shadow-sm">
                    <img src="${country.flags.png}" class="card-img-top" alt="${country.name.common}">
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title">${country.name.common}</h5>
                        <div class="mt-auto">
                            <button class="btn btn-danger btn-remove-favorite w-100 mb-2" data-country='${JSON.stringify(country).replace(/'/g, "&apos;")}'>
                                Remover dos Favoritos
                            </button>
                            <button class="btn btn-info btn-details w-100" data-country='${JSON.stringify(country).replace(/'/g, "&apos;")}'>
                                Ver Detalhes
                            </button>
                        </div>
                    </div>
                </div>
            `;

            countryCard.innerHTML = countryHTML;
            container.appendChild(countryCard);
        });

        // Adicionar eventos aos botões de remover dos favoritos
        const removeFavoriteButtons = document.querySelectorAll(".btn-remove-favorite");
        removeFavoriteButtons.forEach(button => {
            button.addEventListener("click", handleRemoveFavorite);
        });

        // Adicionar eventos aos botões de detalhes
        const detailButtons = document.querySelectorAll(".btn-details");
        detailButtons.forEach(button => {
            button.addEventListener("click", handleDetails);
        });
    }
}

// Função para remover um país dos favoritos
function handleRemoveFavorite(event) {
    try {
        const country = JSON.parse(event.target.dataset.country);
        console.log("Removendo país dos favoritos:", country.name.common); // Log para depuração

        let favoritos = getFavoritos();
        favoritos = favoritos.filter(favorito => favorito.name.common !== country.name.common); // Remove o país da lista
        saveFavoritos(favoritos);
        alert(`${country.name.common} foi removido dos favoritos.`);
        carregarFavoritos(); // Recarrega os favoritos na página
    } catch (error) {
        console.error("Erro ao remover país dos favoritos:", error);
        console.error("JSON string:", event.target.dataset.country); // Log the problematic JSON string
    }
}

// Função para redirecionar para a página de detalhes do país
function handleDetails(event) {
    try {
        const country = JSON.parse(event.target.dataset.country);
        console.log("Vendo detalhes do país:", country.name.common); // Log para depuração
        localStorage.setItem("selectedCountry", JSON.stringify(country));
        window.location.href = "detalhes.html";
    } catch (error) {
        console.error("Erro ao ver detalhes do país:", error);
        console.error("JSON string:", event.target.dataset.country); // Log the problematic JSON string
    }
}

// Função para obter os favoritos do localStorage
function getFavoritos() {
    return JSON.parse(localStorage.getItem("favorites")) || [];
}

// Função para salvar os favoritos no localStorage
function saveFavoritos(favoritos) {
    localStorage.setItem("favorites", JSON.stringify(favoritos));
}