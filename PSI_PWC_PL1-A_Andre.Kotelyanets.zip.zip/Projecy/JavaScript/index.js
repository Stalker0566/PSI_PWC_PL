const API_URL = "https://restcountries.com/v3.1/all";

// Selecionar o container onde os países serão exibidos
const featuredCountriesContainer = document.getElementById("featured-countries");

// Função para buscar países da API
async function fetchCountries() {
    try {
        const response = await fetch(API_URL);
        const countries = await response.json();
        displayRandomCountries(countries);
    } catch (error) {
        console.error("Erro ao buscar países:", error);
    }
}

// Função para exibir países aleatórios na página
function displayRandomCountries(countries) {
    const randomCountries = getRandomCountries(countries, 6); // Selecionar 6 países aleatórios
    featuredCountriesContainer.innerHTML = ""; // Limpar a lista de países antes de exibir os novos resultados

    randomCountries.forEach(country => {
        const countryCard = document.createElement("div");
        countryCard.classList.add("col-md-4", "mb-4");

        const countryHTML = `
            <div class="card">
                <img src="${country.flags.png}" class="card-img-top" alt="${country.name.common}">
                <div class="card-body">
                    <h5 class="card-title">${country.name.common}</h5>
                    <p class="card-text">${country.region}</p>
                </div>
            </div>
        `;

        countryCard.innerHTML = countryHTML;
        featuredCountriesContainer.appendChild(countryCard);
    });
}

// Função para obter uma lista de países aleatórios
function getRandomCountries(countries, num) {
    const shuffled = countries.sort(() => 0.5 - Math.random());
    return shuffled.slice(0, num);
}

// Buscar e exibir os países ao carregar a página
fetchCountries();