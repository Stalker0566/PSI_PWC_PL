const API_URL = "https://restcountries.com/v3.1/all";

// Selecionar o container onde os países serão exibidos
const countryList = document.getElementById("country-list");

// Selecionar o formulário de busca e o campo de entrada
const searchForm = document.getElementById("search-form");
const searchInput = document.getElementById("search-input");

// Adicionar evento de submissão ao formulário de busca
searchForm.addEventListener("submit", function (event) {
    event.preventDefault();
    const query = searchInput.value.trim().toLowerCase();
    fetchCountries(query);
});

// Função para buscar países da API com um parâmetro de consulta
async function fetchCountries(query = "") {
    try {
        const response = await fetch(API_URL);
        const countries = await response.json();
        const filteredCountries = countries.filter(country =>
            country.name.common.toLowerCase().includes(query)
        );
        displayCountries(filteredCountries);
    } catch (error) {
        console.error("Erro ao buscar países:", error);
    }
}

// Função para exibir os países na página
function displayCountries(countries) {
    countryList.innerHTML = ""; // Limpar a lista de países antes de exibir os novos resultados
    countries.forEach(country => {
        console.log("Exibindo país:", country.name.common); // Log para depuração
        const countryCard = document.createElement("div");
        countryCard.classList.add("col-md-4", "col-sm-6", "mb-4");

        const countryHTML = `
            <div class="card h-100 shadow-sm">
                <img src="${country.flags.png}" class="card-img-top" alt="${country.name.common}">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title">${country.name.common}</h5>
                    <div class="mt-auto">
                        <button class="btn btn-primary btn-favorite w-100 mb-2" data-country='${JSON.stringify(country).replace(/'/g, "&apos;")}'>
                            Favoritar
                        </button>
                        <button class="btn btn-info btn-details w-100" data-country='${JSON.stringify(country).replace(/'/g, "&apos;")}'>
                            Ver Detalhes
                        </button>
                    </div>
                </div>
            </div>
        `;

        countryCard.innerHTML = countryHTML;
        countryList.appendChild(countryCard);
    });

    // Adicionar eventos aos botões de favoritar
    const favoriteButtons = document.querySelectorAll(".btn-favorite");
    favoriteButtons.forEach(button => {
        button.addEventListener("click", handleFavorite);
    });

    // Adicionar eventos aos botões de detalhes
    const detailButtons = document.querySelectorAll(".btn-details");
    detailButtons.forEach(button => {
        button.addEventListener("click", handleDetails);
    });
}

// Função para adicionar um país aos favoritos
function handleFavorite(event) {
    try {
        const country = JSON.parse(event.target.dataset.country);
        console.log("Favoritando país:", country.name.common); // Log para depuração

        // Recuperar favoritos do localStorage
        const favorites = JSON.parse(localStorage.getItem("favorites")) || [];

        // Adicionar o país aos favoritos (se ainda não estiver na lista)
        if (!favorites.some(fav => fav.name.common === country.name.common)) {
            favorites.push(country);
            localStorage.setItem("favorites", JSON.stringify(favorites));
            alert(`${country.name.common} foi adicionado aos favoritos!`);
        } else {
            alert(`${country.name.common} já está nos favoritos.`);
        }
    } catch (error) {
        console.error("Erro ao favoritar país:", error);
        console.error("JSON string:", event.target.dataset.country); // Log the problematic JSON string
    }
}

// Função para redirecionar para a página de detalhes do país
function handleDetails(event) {
    try {
        const country = JSON.parse(event.target.dataset.country);
        console.log("Vendo detalhes do país:", country.name.common); // Log para depuração
        localStorage.setItem("selectedCountry", JSON.stringify(country));
        window.location.href = "detalhes.html";
    } catch (error) {
        console.error("Erro ao ver detalhes do país:", error);
        console.error("JSON string:", event.target.dataset.country); // Log the problematic JSON string
    }
}

// Buscar e exibir os países ao carregar a página
fetchCountries();

// Função para exibir os favoritos na página de favoritos
function carregarFavoritos() {
    const favoritos = getFavoritos();
    const container = document.getElementById('favoritosContainer');
    container.innerHTML = ''; // Limpa o container antes de carregar os favoritos
    if (favoritos.length === 0) {
        container.innerHTML = '<p>Nenhum país foi adicionado aos favoritos ainda.</p>';
    } else {
        favoritos.forEach(pais => {
            const div = document.createElement('div');
            div.className = 'col-md-4';
            div.innerHTML = `
                <div class="card">
                    <img src="https://via.placeholder.com/300x200" class="card-img-top" alt="${pais}">
                    <div class="card-body">
                        <h5 class="card-title">${pais}</h5>
                        <button class="btn btn-danger" onclick="removerDosFavoritos('${pais}')">Remover dos Favoritos</button>
                    </div>
                </div>
            `;
            container.appendChild(div);
        });
    }
}

// Função para remover um país dos favoritos
function removerDosFavoritos(pais) {
    let favoritos = getFavoritos();
    favoritos = favoritos.filter(favorito => favorito !== pais); // Remove o país da lista
    saveFavoritos(favoritos);
    alert(`${pais} foi removido dos favoritos.`);
    carregarFavoritos(); // Recarrega os favoritos na página
}

// Função para obter os favoritos do localStorage
function getFavoritos() {
    return JSON.parse(localStorage.getItem("favorites")) || [];
}

// Função para salvar os favoritos no localStorage
function saveFavoritos(favoritos) {
    localStorage.setItem("favorites", JSON.stringify(favoritos));
}
