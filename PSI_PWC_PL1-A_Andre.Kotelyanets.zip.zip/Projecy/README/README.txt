Project: Explore the World
Project Description
"Explore the World" is an interactive website designed to provide an immersive experience of discovering and exploring countries around the world. The goal of this project is to allow users to search for, explore, and learn about different countries, including their cultures, capitals, populations, currencies, languages, and other important information. The platform uses the REST Countries API to provide real-time and detailed country information.

Main Features
Homepage

Introduction to the project and the concept of exploring the world.
An interactive carousel with images of popular destinations.
Buttons that lead users to different sections of the website.
Country Search

Users can search for specific countries using a search bar.
The search is performed in real-time, utilizing the REST Countries API to fetch country data.
As users type the name of a country, the system returns data like the official name, capital, population, languages, currency, flag, and geographical location.
Display of country information in a clear and organized manner.
Country Details Page

By selecting a country from the search results, users can access a detailed page with in-depth information, including:
Official name
Capital city
Population
Spoken languages
Currency used
Geographical location
Flag image
Favorites

Users can save their favorite countries using Web Storage (localStorage), ensuring that the favorite countries are preserved even after the browser is closed.
A "Favorites" page displays the saved countries, with the option to remove them from the list.
About Page

Information about the developers of the project, including links to their social media profiles and descriptions of their roles in developing the website.
Contact Page

A contact page with information for users to get in touch with the project team.
Technologies Used
HTML: Used to structure the pages and define the layout of the website.
CSS: Used to style and create an attractive and responsive design.
JavaScript: Implements dynamic functionality such as country search using the API, favorites management, and interactivity of the website.
Bootstrap: CSS framework for responsive design and ready-to-use components like carousels and buttons.
REST Countries API: External API that provides detailed information about countries, such as name, capital, population, currency, languages, etc. The API is used to fetch country data in real-time.
Web Storage (localStorage): Used to store the user's favorite countries locally in the browser, ensuring that the data is preserved across sessions.
Project Structure
index.html: The homepage with an introduction and carousel.
paises.html: Country search page where users can search for and view information about countries.
detalhes.html: A detailed page for a specific country, showing in-depth information.
favoritos.html: A page displaying the saved favorite countries.
contactos.html: Contact information page.
style.css: CSS file for customizing the layout and design of the website.
script.js: JavaScript file implementing dynamic functionalities such as fetching country data via the API, managing favorites, and interacting with Web Storage.
How to Use
Accessing the Project:

Clone or download the project repository.
Open the HTML files in a browser to view the website pages.
Searching for Countries:

Go to the "Countries" page and type the name of a country in the search bar.
The page will display the corresponding results with details about the country.
Click on the country name to view a detailed page with complete information.
Adding Countries to Favorites:

On the country details page, you can click a button to add the country to your list of favorites.
The favorites list will be saved in the browser and will be available in the "Favorites" page, even after the browser is closed.
Viewing Favorites:

Visit the "Favorites" page to view all the countries you have saved as favorites.
You can remove countries from the favorites list at any time.
Technical Implementation
Integration with REST Countries API:

The project uses the REST Countries API to retrieve information about countries. The request is made using JavaScript’s fetch() method to retrieve data in real-time.
The API returns the data in JSON format, which is dynamically displayed on the country search and details pages.
Web Storage Implementation:

The website uses localStorage to store the user's favorite countries. This ensures that the favorite countries are retained across browser sessions.
