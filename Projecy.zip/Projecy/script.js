$(document).ready(function () {
    $('#search-form').on('submit', function (e) {
        e.preventDefault(); // Evita o recarregamento da página
        const query = $('#search-input').val().trim().toLowerCase();

        if (!query) {
            alert("Digite o nome de um país para pesquisar.");
            return;
        }

        // Faz a requisição AJAX para a API Rest Countries
        $.ajax({
            url: 'https://restcountries.com/v3.1/all',
            method: 'GET',
            success: function (data) {
                const resultsList = $('#countries-list');
                resultsList.empty(); // Limpa os resultados anteriores

                // Filtra os países pelo nome
                const filteredCountries = data.filter(country =>
                    country.name.common.toLowerCase().includes(query)
                );

                if (filteredCountries.length === 0) {
                    resultsList.append('<li class="list-group-item">Nenhum país encontrado.</li>');
                    return;
                }

                // Exibe os resultados
                filteredCountries.forEach(country => {
                    const li = `
                        <li class="list-group-item">
                            <strong>${country.name.common}</strong> - ${country.region} (${country.cca2})
                        </li>`;
                    resultsList.append(li);
                });
            },
            error: function (error) {
                console.error('Erro ao buscar países:', error);
                alert('Erro ao buscar países. Tente novamente mais tarde.');
            }
        });
    });
});
