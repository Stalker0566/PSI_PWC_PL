// favoritos.js

// Selecionar o container onde os favoritos serão exibidos
const favoritesList = document.getElementById("favorites-list");

// Função para exibir os países favoritos
function displayFavorites() {
    const favorites = JSON.parse(localStorage.getItem("favorites")) || [];

    favorites.forEach(country => {
        const countryCard = document.createElement("div");
        countryCard.classList.add("col-md-4");

        const countryHTML = `
            <div class="card mb-4">
                <img src="${country.flags.png}" class="card-img-top" alt="${country.name.common}">
                <div class="card-body">
                    <h5 class="card-title">${country.name.common}</h5>
                </div>
            </div>
        `;

        countryCard.innerHTML = countryHTML;
        favoritesList.appendChild(countryCard);
    });
}

// Exibir os países favoritos ao carregar a página
displayFavorites();
