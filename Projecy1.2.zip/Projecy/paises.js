// paises.js

// URL da API REST Countries
const API_URL = "https://restcountries.com/v3.1/all";

// Selecionar o container onde os países serão exibidos
const countryList = document.getElementById("country-list");

// Função para buscar países da API
async function fetchCountries() {
    try {
        const response = await fetch(API_URL);
        const countries = await response.json();
        displayCountries(countries);
    } catch (error) {
        console.error("Erro ao buscar países:", error);
    }
}

// Função para exibir os países na página
function displayCountries(countries) {
    countries.forEach(country => {
        const countryCard = document.createElement("div");
        countryCard.classList.add("col-md-4");

        const countryHTML = `
            <div class="card mb-4">
                <img src="${country.flags.png}" class="card-img-top" alt="${country.name.common}">
                <div class="card-body">
                    <h5 class="card-title">${country.name.common}</h5>
                    <button class="btn btn-primary btn-favorite" data-country='${JSON.stringify(country)}'>
                        Favoritar
                    </button>
                </div>
            </div>
        `;

        countryCard.innerHTML = countryHTML;
        countryList.appendChild(countryCard);
    });

    // Adicionar eventos aos botões de favoritar
    const favoriteButtons = document.querySelectorAll(".btn-favorite");
    favoriteButtons.forEach(button => {
        button.addEventListener("click", handleFavorite);
    });
}

// Função para adicionar um país aos favoritos
function handleFavorite(event) {
    const country = JSON.parse(event.target.dataset.country);

    // Recuperar favoritos do localStorage
    const favorites = JSON.parse(localStorage.getItem("favorites")) || [];

    // Adicionar o país aos favoritos (se ainda não estiver na lista)
    if (!favorites.some(fav => fav.name.common === country.name.common)) {
        favorites.push(country);
        localStorage.setItem("favorites", JSON.stringify(favorites));
        alert(`${country.name.common} foi adicionado aos favoritos!`);
    } else {
        alert(`${country.name.common} já está nos favoritos.`);
    }
}

// Buscar e exibir os países ao carregar a página
fetchCountries();



// Função para exibir os favoritos na página de favoritos
function carregarFavoritos() {
    const favoritos = getFavoritos();
    const container = document.getElementById('favoritosContainer');
    container.innerHTML = ''; // Limpa o container antes de carregar os favoritos
    if (favoritos.length === 0) {
        container.innerHTML = '<p>Nenhum país foi adicionado aos favoritos ainda.</p>';
    } else {
        favoritos.forEach(pais => {
            const div = document.createElement('div');
            div.className = 'col-md-4';
            div.innerHTML = `
                <div class="card">
                    <img src="https://via.placeholder.com/300x200" class="card-img-top" alt="${pais}">
                    <div class="card-body">
                        <h5 class="card-title">${pais}</h5>
                        <button class="btn btn-danger" onclick="removerDosFavoritos('${pais}')">Remover dos Favoritos</button>
                    </div>
                </div>
            `;
            container.appendChild(div);
        });
    }
}

// Função para remover um país dos favoritos
function removerDosFavoritos(pais) {
    let favoritos = getFavoritos();
    favoritos = favoritos.filter(favorito => favorito !== pais); // Remove o país da lista
    saveFavoritos(favoritos);
    alert(`${pais} foi removido dos favoritos.`);
    carregarFavoritos(); // Recarrega os favoritos na página
}
